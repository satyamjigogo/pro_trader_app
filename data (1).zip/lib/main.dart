import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

// Aapki alag banayi hui files ke imports:
import 'models/trading_models.dart';
import 'screens/terminal_screen.dart';
import 'screens/markets_screen.dart';
import 'screens/portfolio_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/leaderboard_screen.dart';
import 'screens/news_screen.dart';

void main() {
  runApp(const UltimateTradingApp());
}

class UltimateTradingApp extends StatelessWidget {
  const UltimateTradingApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pro Trader Station',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF090B10),
        primaryColor: const Color(0xFF00E676),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF00E676),
          secondary: Color(0xFFFF1744),
          surface: Color(0xFF121620),
        ),
      ),
      home: const MainContainerScreen(),
    );
  }
}

class MainContainerScreen extends StatefulWidget {
  const MainContainerScreen({super.key});

  @override
  State<MainContainerScreen> createState() => _MainContainerScreenState();
}

class _MainContainerScreenState extends State<MainContainerScreen> {
  int _currentIndex = 0;
  double _walletBalance = 100000.00;
  String _selectedTimeframe = '1m';
  bool _showMA = true;
  bool _showRSI = false;

  String _userName = 'Pro Trader';
  String _userAvatar = 'https://i.pravatar.cc/150?img=12';
  final TextEditingController _nameCtrl = TextEditingController();
  final TextEditingController _avatarCtrl = TextEditingController();

  late List<StockItem> _stocks;
  late StockItem _activeStock;
  final List<PositionItem> _positions = [];
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _nameCtrl.text = _userName;
    _avatarCtrl.text = _userAvatar;
    _initStocks();
    _startEngine();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _nameCtrl.dispose();
    _avatarCtrl.dispose();
    super.dispose();
  }

  void _saveProfile() {
    setState(() {
      _userName = _nameCtrl.text;
      _userAvatar = _avatarCtrl.text;
    });
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Profile updated successfully!')),
    );
  }

  void _initStocks() {
    final now = DateTime.now();
    _stocks = [
      StockItem(
          symbol: 'NVDA',
          name: 'NVIDIA Corp',
          category: 'Tech',
          currentPrice: 135.80,
          changePercent: 3.50,
          candles: _generateCandles(135.80, now)),
      StockItem(
          symbol: 'AAPL',
          name: 'Apple Inc',
          category: 'Tech',
          currentPrice: 234.10,
          changePercent: 1.20,
          candles: _generateCandles(234.10, now)),
      StockItem(
          symbol: 'MSFT',
          name: 'Microsoft',
          category: 'Tech',
          currentPrice: 462.50,
          changePercent: -0.50,
          candles: _generateCandles(462.50, now)),
      StockItem(
          symbol: 'TSLA',
          name: 'Tesla Motors',
          category: 'Auto',
          currentPrice: 256.40,
          changePercent: -2.10,
          candles: _generateCandles(256.40, now)),
      StockItem(
          symbol: 'BTC/USD',
          name: 'Bitcoin',
          category: 'Crypto',
          currentPrice: 67200.00,
          changePercent: 4.10,
          candles: _generateCandles(67200.00, now)),
    ];
    _activeStock = _stocks[0];
  }

  List<Candle> _generateCandles(double basePrice, DateTime endTime) {
    List<Candle> list = [];
    double price = basePrice;
    final rand = Random();
    for (int i = 50; i >= 0; i--) {
      double open = price;
      double delta = (rand.nextDouble() - 0.48) * (basePrice * 0.012);
      double close = open + delta;
      list.add(Candle(
        open: open,
        high: max(open, close) + rand.nextDouble() * (basePrice * 0.004),
        low: min(open, close) - rand.nextDouble() * (basePrice * 0.004),
        close: close,
        time: endTime.subtract(Duration(minutes: i * 2)),
      ));
      price = close;
    }
    return list;
  }

  void _startEngine() {
    _timer = Timer.periodic(const Duration(seconds: 2), (_) {
      if (!mounted) return;
      setState(() {
        final rand = Random();
        for (var stock in _stocks) {
          final fluctuation =
              (rand.nextDouble() - 0.49) * (stock.currentPrice * 0.006);
          final newPrice = double.parse(
              (stock.currentPrice + fluctuation).toStringAsFixed(2));
          stock.currentPrice = newPrice;
          stock.changePercent +=
              double.parse((fluctuation * 0.03).toStringAsFixed(2));

          if (stock.candles.isNotEmpty) {
            Candle last = stock.candles.last;
            stock.candles[stock.candles.length - 1] = Candle(
              open: last.open,
              high: max(last.high, newPrice),
              low: min(last.low, newPrice),
              close: newPrice,
              time: last.time,
            );
          }
        }
      });
    });
  }

  void _showTradeDialog(bool isLong) {
    final qtyCtrl = TextEditingController(text: '1');
    int leverage = 1;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF121620),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setModal) {
            return Padding(
              padding: EdgeInsets.only(
                  bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
                  left: 20,
                  right: 20,
                  top: 20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('${isLong ? "BUY" : "SELL"} ${_activeStock.symbol}',
                      style: const TextStyle(
                          fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 10),
                  TextField(
                      controller: qtyCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                          labelText: 'Quantity', border: OutlineInputBorder())),
                  const SizedBox(height: 10),
                  const Text('Leverage:',
                      style: TextStyle(color: Colors.grey, fontSize: 12)),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [1, 2, 5, 10].map((lev) {
                      return ChoiceChip(
                        label: Text('${lev}x'),
                        selected: leverage == lev,
                        onSelected: (_) => setModal(() => leverage = lev),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 15),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: isLong
                            ? const Color(0xFF00E676)
                            : const Color(0xFFFF1744)),
                    onPressed: () {
                      final qty = int.tryParse(qtyCtrl.text) ?? 1;
                      final cost = (_activeStock.currentPrice * qty) / leverage;
                      if (cost <= _walletBalance) {
                        setState(() {
                          _walletBalance -= cost;
                          _positions.add(PositionItem(
                            symbol: _activeStock.symbol,
                            quantity: qty,
                            entryPrice: _activeStock.currentPrice,
                            isLong: isLong,
                            leverage: leverage,
                            timestamp: DateTime.now(),
                          ));
                        });
                      }
                      Navigator.pop(ctx);
                    },
                    child: const Text('CONFIRM ORDER',
                        style: TextStyle(
                            color: Colors.black, fontWeight: FontWeight.bold)),
                  )
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF121620),
        title: Text(
            '${_activeStock.symbol} \$${_activeStock.currentPrice.toStringAsFixed(2)}'),
        actions: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Text('\$${_walletBalance.toStringAsFixed(2)}',
                style: const TextStyle(
                    fontWeight: FontWeight.bold, color: Colors.amber)),
          )
        ],
      ),
      body: IndexedStack(
        index: _currentIndex,
        children: [
          // 1. Terminal Screen
          TerminalScreen(
            activeStock: _activeStock,
            selectedTimeframe: _selectedTimeframe,
            onTimeframeChanged: (tf) => setState(() => _selectedTimeframe = tf),
            showMA: _showMA,
            showRSI: _showRSI,
            onToggleMA: (v) => setState(() => _showMA = v),
            onToggleRSI: (v) => setState(() => _showRSI = v),
            onBuy: () => _showTradeDialog(true),
            onSell: () => _showTradeDialog(false),
          ),

          // 2. Markets Screen
          MarketsScreen(
            stocks: _stocks,
            activeStock: _activeStock,
            onSelectStock: (st) => setState(() {
              _activeStock = st;
              _currentIndex = 0;
            }),
          ),

          // 3. Portfolio Screen
          PortfolioScreen(
            walletBalance: _walletBalance,
            positions: _positions,
            stocks: _stocks,
          ),

          // 4. Leaderboard Screen
          const LeaderboardScreen(),

          // 5. News Screen
          const NewsScreen(),

          // 6. Profile Screen
          ProfileScreen(
            userName: _userName,
            userAvatar: _userAvatar,
            nameCtrl: _nameCtrl,
            avatarCtrl: _avatarCtrl,
            onSave: _saveProfile,
            onReset: () => setState(() {
              _walletBalance = 100000.0;
              _positions.clear();
            }),
            historyCount: 0,
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        backgroundColor: const Color(0xFF121620),
        selectedItemColor: const Color(0xFF00E676),
        unselectedItemColor: Colors.grey,
        type: BottomNavigationBarType.fixed,
        onTap: (idx) => setState(() => _currentIndex = idx),
        items: const [
          BottomNavigationBarItem(
              icon: Icon(Icons.show_chart), label: 'Terminal'),
          BottomNavigationBarItem(icon: Icon(Icons.search), label: 'Markets'),
          BottomNavigationBarItem(
              icon: Icon(Icons.pie_chart), label: 'Portfolio'),
          BottomNavigationBarItem(
              icon: Icon(Icons.emoji_events), label: 'Ranks'),
          BottomNavigationBarItem(icon: Icon(Icons.newspaper), label: 'News'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}
