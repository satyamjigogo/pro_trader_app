import 'dart:math';
import 'package:flutter/material.dart';
import '../models/trading_models.dart';
import '../widgets/chart_painter.dart';

class TerminalScreen extends StatelessWidget {
  final StockItem activeStock;
  final String selectedTimeframe;
  final Function(String) onTimeframeChanged;
  final bool showMA;
  final bool showRSI;
  final Function(bool) onToggleMA;
  final Function(bool) onToggleRSI;
  final VoidCallback onBuy;
  final VoidCallback onSell;

  const TerminalScreen({
    super.key,
    required this.activeStock,
    required this.selectedTimeframe,
    required this.onTimeframeChanged,
    required this.showMA,
    required this.showRSI,
    required this.onToggleMA,
    required this.onToggleRSI,
    required this.onBuy,
    required this.onSell,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Timeframe & Indicator Bar
        Container(
          color: const Color(0xFF121620),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: ['1m', '5m', '15m', '1H', '1D'].map((tf) {
                  final isSel = selectedTimeframe == tf;
                  return GestureDetector(
                    onTap: () => onTimeframeChanged(tf),
                    child: Container(
                      margin: const EdgeInsets.only(right: 6),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: isSel
                            ? const Color(0xFF00E676).withValues(alpha: 0.2)
                            : Colors.transparent,
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(tf,
                          style: TextStyle(
                              color:
                                  isSel ? const Color(0xFF00E676) : Colors.grey,
                              fontSize: 12,
                              fontWeight: FontWeight.bold)),
                    ),
                  );
                }).toList(),
              ),
              Row(
                children: [
                  FilterChip(
                      label: const Text('MA', style: TextStyle(fontSize: 10)),
                      selected: showMA,
                      onSelected: (v) => onToggleMA(v)),
                  const SizedBox(width: 6),
                  FilterChip(
                      label: const Text('RSI', style: TextStyle(fontSize: 10)),
                      selected: showRSI,
                      onSelected: (v) => onToggleRSI(v)),
                ],
              )
            ],
          ),
        ),
        // Chart
        Expanded(
          flex: 4,
          child: Container(
            margin: const EdgeInsets.all(6),
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
                color: const Color(0xFF121620),
                borderRadius: BorderRadius.circular(10)),
            child: InteractiveViewer(
              panEnabled: true,
              scaleEnabled: true,
              child: CustomPaint(
                size: Size.infinite,
                painter: ChartPainter(
                    candles: activeStock.candles,
                    showMA: showMA,
                    showRSI: showRSI),
              ),
            ),
          ),
        ),
        // Order Book Depth
        Expanded(
          flex: 2,
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 6),
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
                color: const Color(0xFF121620),
                borderRadius: BorderRadius.circular(10)),
            child: Row(
              children: [
                Expanded(child: _buildOrderBookSide('Bids (Buy)', true)),
                const VerticalDivider(color: Colors.white12),
                Expanded(child: _buildOrderBookSide('Asks (Sell)', false)),
              ],
            ),
          ),
        ),
        // Execution Buttons
        Container(
          padding: const EdgeInsets.all(12),
          color: const Color(0xFF121620),
          child: Row(
            children: [
              Expanded(
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF00E676),
                      padding: const EdgeInsets.symmetric(vertical: 14)),
                  onPressed: onBuy,
                  child: const Text('BUY / LONG',
                      style: TextStyle(
                          fontWeight: FontWeight.bold, color: Colors.black)),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFF1744),
                      padding: const EdgeInsets.symmetric(vertical: 14)),
                  onPressed: onSell,
                  child: const Text('SELL / SHORT',
                      style: TextStyle(
                          fontWeight: FontWeight.bold, color: Colors.white)),
                ),
              ),
            ],
          ),
        )
      ],
    );
  }

  Widget _buildOrderBookSide(String title, bool isBid) {
    final rand = Random();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title,
            style: TextStyle(
                fontSize: 11,
                color:
                    isBid ? const Color(0xFF00E676) : const Color(0xFFFF1744),
                fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        Expanded(
          child: ListView.builder(
            itemCount: 4,
            physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (ctx, idx) {
              final price = isBid
                  ? activeStock.currentPrice - (idx * 0.12)
                  : activeStock.currentPrice + (idx * 0.12);
              final qty = (rand.nextInt(40) + 10) * 5;
              return Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('\$${price.toStringAsFixed(2)}',
                      style: const TextStyle(fontSize: 11)),
                  Text('$qty',
                      style: const TextStyle(fontSize: 11, color: Colors.grey)),
                ],
              );
            },
          ),
        )
      ],
    );
  }
}
