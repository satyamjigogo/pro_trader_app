import 'package:flutter/material.dart';
import '../models/trading_models.dart';

class NewsScreen extends StatelessWidget {
  const NewsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<NewsItem> newsList = [
      NewsItem(
          headline:
              'NVIDIA Announces Next-Gen AI Chips with Record Performance',
          source: 'Bloomberg',
          timeAgo: '15m ago',
          isBullish: true),
      NewsItem(
          headline: 'Federal Reserve Hints at Interest Rate Cuts Next Month',
          source: 'Reuters',
          timeAgo: '42m ago',
          isBullish: true),
      NewsItem(
          headline:
              'Tesla Reports Supply Chain Hurdles in European Gigafactories',
          source: 'CNBC',
          timeAgo: '2h ago',
          isBullish: false),
      NewsItem(
          headline:
              'Bitcoin Surges Past Major Resistance Level Amid ETF Inflows',
          source: 'CoinDesk',
          timeAgo: '3h ago',
          isBullish: true),
    ];

    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: newsList.length,
      itemBuilder: (ctx, idx) {
        final news = newsList[idx];
        return Card(
          color: const Color(0xFF121620),
          margin: const EdgeInsets.only(bottom: 10),
          child: ListTile(
            leading: Icon(
              news.isBullish ? Icons.trending_up : Icons.trending_down,
              color: news.isBullish
                  ? const Color(0xFF00E676)
                  : const Color(0xFFFF1744),
            ),
            title: Text(news.headline,
                style:
                    const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
            subtitle: Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text('${news.source} • ${news.timeAgo}',
                  style: const TextStyle(color: Colors.grey, fontSize: 11)),
            ),
          ),
        );
      },
    );
  }
}
