import 'package:flutter/material.dart';
import '../models/trading_models.dart';

class PortfolioScreen extends StatelessWidget {
  final double walletBalance;
  final List<PositionItem> positions;
  final List<StockItem> stocks;

  const PortfolioScreen(
      {super.key,
      required this.walletBalance,
      required this.positions,
      required this.stocks});

  @override
  Widget build(BuildContext context) {
    double totalInvested = 0;
    for (var p in positions) {
      totalInvested += p.entryPrice * p.quantity;
    }

    return Column(
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          color: const Color(0xFF121620),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Available Capital',
                      style: TextStyle(color: Colors.grey, fontSize: 12)),
                  Text('\$${walletBalance.toStringAsFixed(2)}',
                      style: const TextStyle(
                          fontSize: 22, fontWeight: FontWeight.bold)),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  const Text('Invested Value',
                      style: TextStyle(color: Colors.grey, fontSize: 12)),
                  Text('\$${totalInvested.toStringAsFixed(2)}',
                      style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Colors.amber)),
                ],
              ),
            ],
          ),
        ),
        const Padding(
          padding: EdgeInsets.all(12.0),
          child: Align(
              alignment: Alignment.centerLeft,
              child: Text('Active Positions',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),
        ),
        Expanded(
          child: positions.isEmpty
              ? const Center(
                  child: Text('No active trades',
                      style: TextStyle(color: Colors.grey)))
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  itemCount: positions.length,
                  itemBuilder: (ctx, idx) {
                    final pos = positions[idx];
                    final st = stocks.firstWhere((s) => s.symbol == pos.symbol,
                        orElse: () => stocks.first);
                    final pnl = pos.isLong
                        ? (st.currentPrice - pos.entryPrice) *
                            pos.quantity *
                            pos.leverage
                        : (pos.entryPrice - st.currentPrice) *
                            pos.quantity *
                            pos.leverage;
                    final isProfit = pnl >= 0;

                    return Card(
                      color: const Color(0xFF121620),
                      child: ListTile(
                        leading: Icon(
                            pos.isLong
                                ? Icons.arrow_upward
                                : Icons.arrow_downward,
                            color: pos.isLong
                                ? const Color(0xFF00E676)
                                : const Color(0xFFFF1744)),
                        title: Text(
                            '${pos.isLong ? "LONG" : "SHORT"} ${pos.symbol} (${pos.leverage}x)',
                            style:
                                const TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Text(
                            'Qty: ${pos.quantity} | Entry: \$${pos.entryPrice.toStringAsFixed(2)}'),
                        trailing: Text(
                            '${isProfit ? "+" : ""}\$${pnl.toStringAsFixed(2)}',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: isProfit
                                    ? const Color(0xFF00E676)
                                    : const Color(0xFFFF1744))),
                      ),
                    );
                  },
                ),
        )
      ],
    );
  }
}
