import 'package:flutter/material.dart';
import '../models/trading_models.dart';

class MarketsScreen extends StatefulWidget {
  final List<StockItem> stocks;
  final StockItem activeStock;
  final Function(StockItem) onSelectStock;

  const MarketsScreen({
    super.key,
    required this.stocks,
    required this.activeStock,
    required this.onSelectStock,
  });

  @override
  State<MarketsScreen> createState() => _MarketsScreenState();
}

class _MarketsScreenState extends State<MarketsScreen> {
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final filtered = widget.stocks.where((s) {
      return s.symbol.toLowerCase().contains(_query.toLowerCase()) ||
          s.name.toLowerCase().contains(_query.toLowerCase()) ||
          s.category.toLowerCase().contains(_query.toLowerCase());
    }).toList();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12.0),
          child: TextField(
            onChanged: (val) => setState(() => _query = val),
            decoration: InputDecoration(
              hintText: 'Search markets...',
              prefixIcon: const Icon(Icons.search, color: Colors.grey),
              filled: true,
              fillColor: const Color(0xFF121620),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide.none),
            ),
          ),
        ),
        Expanded(
          child: ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            itemCount: filtered.length,
            separatorBuilder: (_, __) => const Divider(color: Colors.white12),
            itemBuilder: (ctx, idx) {
              final st = filtered[idx];
              final isGreen = st.changePercent >= 0;
              return ListTile(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8)),
                tileColor: widget.activeStock.symbol == st.symbol
                    ? const Color(0xFF121620)
                    : Colors.transparent,
                onTap: () => widget.onSelectStock(st),
                title: Text(st.symbol,
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('${st.name} • ${st.category}',
                    style: const TextStyle(color: Colors.grey, fontSize: 12)),
                trailing: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text('\$${st.currentPrice.toStringAsFixed(2)}',
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                    Text(
                        '${isGreen ? "+" : ""}${st.changePercent.toStringAsFixed(2)}%',
                        style: TextStyle(
                            color: isGreen
                                ? const Color(0xFF00E676)
                                : const Color(0xFFFF1744),
                            fontSize: 12)),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
