import 'package:flutter/material.dart';

class LeaderboardScreen extends StatelessWidget {
  const LeaderboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> rankings = [
      {'rank': 1, 'name': 'CryptoKing_99', 'pnl': '+\$42,100', 'roi': '+42.1%'},
      {
        'rank': 2,
        'name': 'WallStreetBull',
        'pnl': '+\$31,400',
        'roi': '+31.4%'
      },
      {'rank': 3, 'name': 'AlphaTrader', 'pnl': '+\$18,900', 'roi': '+18.9%'},
      {
        'rank': 4,
        'name': 'You (Paper Trader)',
        'pnl': '+\$2,500',
        'roi': '+2.5%'
      },
      {'rank': 5, 'name': 'RiskMaster', 'pnl': '-\$4,200', 'roi': '-4.2%'},
    ];

    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: rankings.length,
      itemBuilder: (ctx, idx) {
        final item = rankings[idx];
        final isUser = item['name'].toString().contains('You');
        return Card(
          color: isUser
              ? const Color(0xFF00E676).withValues(alpha: 0.15)
              : const Color(0xFF121620),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: const Color(0xFF090B10),
              child: Text('#${item['rank']}',
                  style: const TextStyle(fontWeight: FontWeight.bold)),
            ),
            title: Text(item['name'],
                style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text('Return: ${item['roi']}',
                style: const TextStyle(color: Colors.grey, fontSize: 12)),
            trailing: Text(item['pnl'],
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: item['pnl'].toString().startsWith('+')
                        ? const Color(0xFF00E676)
                        : const Color(0xFFFF1744))),
          ),
        );
      },
    );
  }
}
