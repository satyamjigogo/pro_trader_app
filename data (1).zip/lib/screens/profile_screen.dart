import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  final String userName;
  final String userAvatar;
  final TextEditingController nameCtrl;
  final TextEditingController avatarCtrl;
  final VoidCallback onSave;
  final VoidCallback onReset;
  final int historyCount;

  const ProfileScreen({
    super.key,
    required this.userName,
    required this.userAvatar,
    required this.nameCtrl,
    required this.avatarCtrl,
    required this.onSave,
    required this.onReset,
    required this.historyCount,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Center(
            child: CircleAvatar(
                radius: 50, backgroundImage: NetworkImage(userAvatar))),
        const SizedBox(height: 20),
        TextField(
            controller: nameCtrl,
            decoration: const InputDecoration(
                labelText: 'Trader Name', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        TextField(
            controller: avatarCtrl,
            decoration: const InputDecoration(
                labelText: 'Avatar Image URL', border: OutlineInputBorder())),
        const SizedBox(height: 16),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF00E676),
              padding: const EdgeInsets.symmetric(vertical: 14)),
          onPressed: onSave,
          child: const Text('SAVE PROFILE',
              style:
                  TextStyle(fontWeight: FontWeight.bold, color: Colors.black)),
        ),
        const SizedBox(height: 30),
        ListTile(
          tileColor: const Color(0xFF121620),
          title: const Text('Closed Trades History Count'),
          trailing: Text('$historyCount',
              style: const TextStyle(fontWeight: FontWeight.bold)),
        ),
        const SizedBox(height: 10),
        ListTile(
          tileColor: const Color(0xFF121620),
          title: const Text('Reset Account Balance'),
          trailing: TextButton(
              onPressed: onReset,
              child: const Text('Reset',
                  style: TextStyle(color: Color(0xFFFF1744)))),
        ),
      ],
    );
  }
}
