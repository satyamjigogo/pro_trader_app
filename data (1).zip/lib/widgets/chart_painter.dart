import 'dart:math';
import 'package:flutter/material.dart';
import '../models/trading_models.dart';

class ChartPainter extends CustomPainter {
  final List<Candle> candles;
  final bool showMA;
  final bool showRSI;

  ChartPainter(
      {required this.candles, required this.showMA, required this.showRSI});

  @override
  void paint(Canvas canvas, Size size) {
    if (candles.isEmpty) return;
    double height = showRSI ? size.height * 0.75 : size.height;
    double maxP = candles.map((c) => c.high).reduce(max);
    double minP = candles.map((c) => c.low).reduce(min);
    double range = (maxP - minP) == 0 ? 1.0 : (maxP - minP);

    double wPerC = size.width / candles.length;
    double cWidth = wPerC * 0.65;

    final green = Paint()..color = const Color(0xFF00E676);
    final red = Paint()..color = const Color(0xFFFF1744);
    final wick = Paint()
      ..strokeWidth = 1.2
      ..style = PaintingStyle.stroke;
    final maPaint = Paint()
      ..color = Colors.amber
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    List<Offset> maList = [];

    for (int i = 0; i < candles.length; i++) {
      final c = candles[i];
      final isGreen = c.close >= c.open;
      final paint = isGreen ? green : red;
      wick.color = isGreen ? const Color(0xFF00E676) : const Color(0xFFFF1744);

      double x = (i * wPerC) + (wPerC / 2);
      double highY = height - ((c.high - minP) / range * height);
      double lowY = height - ((c.low - minP) / range * height);
      double openY = height - ((c.open - minP) / range * height);
      double closeY = height - ((c.close - minP) / range * height);

      canvas.drawLine(Offset(x, highY), Offset(x, lowY), wick);
      canvas.drawRect(
          Rect.fromLTWH(x - (cWidth / 2), min(openY, closeY), cWidth,
              max(1.0, (openY - closeY).abs())),
          paint);

      if (showMA && i >= 3) {
        double sum = 0;
        int cnt = 0;
        for (int j = max(0, i - 4); j <= i; j++) {
          sum += candles[j].close;
          cnt++;
        }
        double avg = sum / cnt;
        maList.add(Offset(x, height - ((avg - minP) / range * height)));
      }
    }

    if (showMA && maList.length > 1) {
      Path path = Path()..moveTo(maList[0].dx, maList[0].dy);
      for (int i = 1; i < maList.length; i++)
        path.lineTo(maList[i].dx, maList[i].dy);
      canvas.drawPath(path, maPaint);
    }

    if (showRSI) {
      double rTop = size.height * 0.8;
      double rH = size.height * 0.2;
      canvas.drawRect(Rect.fromLTWH(0, rTop, size.width, rH),
          Paint()..color = const Color(0xFF090B10));
      Path rPath = Path();
      for (int i = 0; i < candles.length; i++) {
        double x = (i * wPerC) + (wPerC / 2);
        double y =
            rTop + rH - (((30 + (sin(i.toDouble()) * 30 + 30)) / 100) * rH);
        if (i == 0)
          rPath.moveTo(x, y);
        else
          rPath.lineTo(x, y);
      }
      canvas.drawPath(
          rPath,
          Paint()
            ..color = Colors.purpleAccent
            ..strokeWidth = 1.2
            ..style = PaintingStyle.stroke);
    }
  }

  @override
  bool shouldRepaint(covariant ChartPainter oldDelegate) => true;
}
