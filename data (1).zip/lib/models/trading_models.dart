class Candle {
  final double open;
  final double high;
  final double low;
  final double close;
  final DateTime time;

  Candle(
      {required this.open,
      required this.high,
      required this.low,
      required this.close,
      required this.time});
}

class StockItem {
  final String symbol;
  final String name;
  final String category;
  double currentPrice;
  double changePercent;
  List<Candle> candles;

  StockItem(
      {required this.symbol,
      required this.name,
      required this.category,
      required this.currentPrice,
      required this.changePercent,
      required this.candles});
}

class PositionItem {
  final String symbol;
  final int quantity;
  final double entryPrice;
  final bool isLong;
  final double? stopLoss;
  final double? takeProfit;
  final int leverage;
  final bool isLimitOrder;
  final double? limitPrice;
  final DateTime timestamp;

  PositionItem({
    required this.symbol,
    required this.quantity,
    required this.entryPrice,
    required this.isLong,
    this.stopLoss,
    this.takeProfit,
    required this.leverage,
    this.isLimitOrder = false,
    this.limitPrice,
    required this.timestamp,
  });
}

class ClosedTradeItem {
  final String symbol;
  final int quantity;
  final double entryPrice;
  final double exitPrice;
  final bool isLong;
  final double realizedPnl;
  final DateTime closedAt;

  ClosedTradeItem(
      {required this.symbol,
      required this.quantity,
      required this.entryPrice,
      required this.exitPrice,
      required this.isLong,
      required this.realizedPnl,
      required this.closedAt});
}

class NewsItem {
  final String headline;
  final String source;
  final String timeAgo;
  final bool isBullish;

  NewsItem(
      {required this.headline,
      required this.source,
      required this.timeAgo,
      required this.isBullish});
}
